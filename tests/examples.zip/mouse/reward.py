def reward_function(rew: dict):
    return rew["found_cheese"] * 2
